﻿V1.7.1 (2021-11-8)
    Translated (loosely)
    small fixes

M.u.g.e.n character settings

Software Description:
Used for gadgets for M.G.E.N character settings, more features are being developed ...
Run the .NET Framework 4.0 framework, such as an run error, please download the installation required component: https://www.microsoft.com/zh-/download/details.aspx? Id = 17718

Project address: https://github.com/miaolapd/mugen-chars-set

Mugen Chars SET Development Team
================================================================================================================================================================================================ ==
Update log:

V1.7.0 (2016-10-17)
    Restore uses the default code to save MUGEN related files
    Support for saving people Chinese name

V1.6.0 (2016-10-16)
    Use UTF-8 encoding to save MUGEN-related files (with serious bug, do not use this version)

V1.5.0 (2014-01-23)
    Replace it to .NET Framework 4.0 framework
    Increase the function of adding a character file or compressed package
    Add the function of replacing the Fight.def file
    The characters who have not added Select.def file display unsigned
    Can be dragged to the window from the character DEF file in the current character list
    Save program configuration using XML file

V1.4.1 (2014-01-11)
    Increase the function of previewing the character model of specified color table file

V1.4.0 (2014-01-10)
    Increase the function of displaying the character model
    Increase whether the function is displayed to show the function of the human width / Pu screen mark

V1.3.2 (2014-01-03)
    Support Mugen WIN version
    Press button setting to display button name

V1.3.1 (2013-12-24)
    Correct Bug when modifying gravity

V1.3.0 (2013-12-24)
    Increase the function of the conversion wide / Push-screen character package
    Add edit main program configuration
    Delete the characters while deleting the characters on Select.def
    Fix some bugs when reading files

V1.2.1 (2013-12-19)
    Fix the bug that selection select.def file lookup path

V1.2.0 (2013-12-19)
    Reconstruction procedure code
    Add Selection System.def and Select.def functionality
    Increase all search functions
    Increase replication person DEF file path function
    Increase the total number of characters and number of items selected
    Some small modifications

V1.1.0 (2013-12-13)
    Add the function of reading the list of characters in Select.def
    Increase the function of deleting characters
    Displays the same attribute as the value of the value

V1.0.0 (2013-12-11)
    First release
